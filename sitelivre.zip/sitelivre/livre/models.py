from django.db import models
from django.core.validators import MinValueValidator,MaxValueValidator


class Livre(models.Model):
    titre = models.CharField(max_length=200)
    auteur = models.CharField(max_length=100)
    annee_publication = models.DateField()

    def __str__(self):
        return self.titre

class Review(models.Model):
    livre = models.ForeignKey(Livre, on_delete=models.CASCADE)
    user_name = models.CharField(max_length=50)
    rating = models.FloatField(validators=[MinValueValidator(1), MaxValueValidator(5)])
    comment = models.TextField()

    def __str__(self):
        return f"Review de {self.livre.titre} par {self.user_name}"


    def clean(self):
        if self.rating < 1 or self.rating > 5:
            raise ValidationError("La note doit etre entre 1 et 5.") 

        if not self.comment.strip():
            raise ValidationError("Le commentaire est obligatoire.")       


