from django.urls import path
from . import views

urlpatterns = [
    path('', views.liste_livres, name='liste_livres'),
    path('livre/<int:livre_id>/', views.details_livre, name='details_livre'),
]
