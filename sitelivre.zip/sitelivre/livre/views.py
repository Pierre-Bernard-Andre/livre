
from django.shortcuts import render, get_object_or_404
from .models import Livre


def accueil(request):
    return render(request, 'accueil.html')

def liste_livres(request):
    livres = Livre.objects.all()
    return render(request, 'liste_livres.html', {'livres': livres})

def details_livre(request, livre_id):
    livre = get_object_or_404(Livre, pk=livre_id)
    reviews = livre.review_set.all()

    return render(request, 'details_livre.html', {'livre': livre, 'reviews': reviews})


